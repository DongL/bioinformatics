# Aesthetic ASCII

Generate **A E S T H E T I C** ASCII art.